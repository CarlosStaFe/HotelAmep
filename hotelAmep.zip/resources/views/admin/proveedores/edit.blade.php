@extends('adminlte::page')

@section('content_header')
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ url('/admin') }}">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Proveedores</li>
            <li class="breadcrumb-item active" aria-current="page">Editar Proveedor</li>
        </ol>
    </nav>
@stop

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h2 class="card-title"><b>Completar el formulario</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <form action="{{ url('/admin/proveedores/' . $proveedor->id) }}" method="POST">
                        @method('PUT')
                        @csrf
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <label for="nombre" class="form-label">Nombre <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                    placeholder="Ingrese nombre del proveedor"
                                    value="{{ old('nombre', $proveedor->nombre) }}" required>
                                @error('nombre')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-4">
                                <label for="razonSocial" class="form-label">Razón Social <b
                                        style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="razonSocial" name="razonSocial"
                                    placeholder="Ingrese razón social del proveedor"
                                    value="{{ old('razonSocial', $proveedor->razonSocial) }}" required>
                                @error('razonSocial')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="cuit" class="form-label">C.U.I.T. <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="cuit" name="cuit"
                                    placeholder="Ingrese C.U.I.T. del proveedor"
                                    value="{{ old('cuit', $proveedor->cuit) }}" required>
                                @error('cuit')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="form-group">
                                    <label for="tipoIva">Tipo I.V.A. <b style="color: red;">(*)</b></label>
                                    <select class="form-control" id="tipoIva" name="tipoIva" required>
                                        <option value="">Elige una tipo de I.V.A...</option>
                                        <option value="Consumidor Final" {{ old('tipoIva', $proveedor->tipoIva) == 'Consumidor Final' ? 'selected' : '' }}>Consumidor Final</option>
                                        <option value="Exento" {{ old('tipoIva', $proveedor->tipoIva) == 'Exento' ? 'selected' : '' }}>Exento</option>
                                        <option value="Monotributo" {{ old('tipoIva', $proveedor->tipoIva) == 'Monotributo' ? 'selected' : '' }}>Monotributo</option>
                                        <option value="No Responsable" {{ old('tipoIva', $proveedor->tipoIva) == 'No Responsable' ? 'selected' : '' }}>No Responsable</option>
                                        <option value="Resp. Inscripto" {{ old('tipoIva', $proveedor->tipoIva) == 'Resp. Inscripto' ? 'selected' : '' }}>Resp. Inscripto</option>
                                    </select>
                                    @error('tipoIva')
                                        <small style="color: red">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <label for="domicilio" class="form-label">Domicilio <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="domicilio" name="domicilio"
                                    placeholder="Ingrese domicilio del proveedor"
                                    value="{{ old('domicilio', $proveedor->domicilio) }}" required>
                                @error('domicilio')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-2 mb-2">
                                <div class="form-group">
                                    <label for="provincia">Provincia <b style="color: red;">(*)</b></label>
                                    <select class="form-control" id="provincia" name="provincia" required>
                                        <option value="">Elige provincia...</option>
                                        <option value="6" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '6' ? 'selected' : '' }}>BUENOS AIRES</option>
                                        <option value="2" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '2' ? 'selected' : '' }}>CABA</option>
                                        <option value="10" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '10' ? 'selected' : '' }}>CATAMARCA</option>
                                        <option value="22" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '22' ? 'selected' : '' }}>CHACO</option>
                                        <option value="26" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '26' ? 'selected' : '' }}>CHUBUT</option>
                                        <option value="18" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '18' ? 'selected' : '' }}>CORRIENTES</option>
                                        <option value="14" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '14' ? 'selected' : '' }}>CORDOBA</option>
                                        <option value="30" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '30' ? 'selected' : '' }}>ENTRE RIOS</option>
                                        <option value="34" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '34' ? 'selected' : '' }}>FORMOSA</option>
                                        <option value="38" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '38' ? 'selected' : '' }}>JUJUY</option>
                                        <option value="42" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '42' ? 'selected' : '' }}>LA PAMPA</option>
                                        <option value="46" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '46' ? 'selected' : '' }}>LA RIOJA</option>
                                        <option value="50" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '50' ? 'selected' : '' }}>MENDOZA</option>
                                        <option value="54" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '54' ? 'selected' : '' }}>MISIONES</option>
                                        <option value="58" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '58' ? 'selected' : '' }}>NEUQUEN</option>
                                        <option value="62" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '62' ? 'selected' : '' }}>RIO NEGRO</option>
                                        <option value="70" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '70' ? 'selected' : '' }}>SAN JUAN</option>
                                        <option value="74" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '74' ? 'selected' : '' }}>SAN LUIS</option>
                                        <option value="66" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '66' ? 'selected' : '' }}>SALTA</option>
                                        <option value="78" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '78' ? 'selected' : '' }}>SANTA CRUZ</option>
                                        <option value="82" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '82' ? 'selected' : '' }}>SANTA FE</option>
                                        <option value="86" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '86' ? 'selected' : '' }}>SANTIAGO DEL ESTERO</option>
                                        <option value="94" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '94' ? 'selected' : '' }}>TIERRA DEL FUEGO</option>
                                        <option value="90" {{ old('provincia', optional($proveedor->localidad)->id_prov) == '90' ? 'selected' : '' }}>TUCUMAN</option>
                                    </select>
                                    @error('provincia')
                                        <small style="color: red">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="form-group">
                                    <label for="localidad">Localidad <b style="color: red;">(*)</b></label>
                                    <select class="form-control" id="localidad" name="localidad" required>
                                    </select>
                                    @error('localidad')
                                        <small style="color: red">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-2">
                                <div class="form-group">
                                    <label for="cod_postal_id">Cod.Postal <b style="color: red;">(*)</b></label>
                                    <select class="form-control" id="cod_postal_id" name="cod_postal_id" required>
                                    </select>
                                    @error('cod_postal_id')
                                        <small style="color: red">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <label for="telefono" class="form-label">Teléfono</label>
                                <input type="text" class="form-control" id="telefono" name="telefono"
                                    placeholder="Ingrese teléfono del proveedor"
                                    value="{{ old('telefono', $proveedor->telefono) }}">
                                @error('telefono')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-4">
                                <label for="email" class="form-label">Email <b style="color: red;">(*)</b></label>
                                <input type="email" class="form-control" id="email" name="email"
                                    placeholder="Ingrese email del proveedor"
                                    value="{{ old('email', $proveedor->email) }}" required>
                                @error('email')
                                    <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="activo" class="form-label">Estado <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="activo" name="activo" required>
                                    <option value="1" {{ old('activo', $proveedor->activo) == '1' ? 'selected' : '' }}>Activo</option>
                                    <option value="0" {{ old('activo', $proveedor->activo) == '0' ? 'selected' : '' }}>Inactivo</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <label for="observacion" class="form-label">Observación</label>
                                <textarea class="form-control" id="observacion" name="observacion" rows="2"
                                    placeholder="Ingrese observación del proveedor">{{ old('observacion', $proveedor->observacion) }}</textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 mb-3">
                                <label for="echeck" class="form-label">Echeck</label>
                                <select class="form-control" id="echeck" name="echeck">
                                    <option value="0" {{ old('echeck', $proveedor->echeck) == '0' ? 'selected' : '' }}>No</option>
                                    <option value="1" {{ old('echeck', $proveedor->echeck) == '1' ? 'selected' : '' }}>Sí</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="cbu" class="form-label">CBU</label>
                                <input type="text" class="form-control" id="cbu" name="cbu"
                                    placeholder="Ingrese CBU del proveedor" value="{{ old('cbu', $proveedor->cbu) }}">
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="cvu" class="form-label">CVU</label>
                                <input type="text" class="form-control" id="cvu" name="cvu"
                                    placeholder="Ingrese CVU del proveedor" value="{{ old('cvu', $proveedor->cvu) }}">
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="alias" class="form-label">Alias</label>
                                <input type="text" class="form-control" id="alias" name="alias"
                                    placeholder="Ingrese alias del proveedor" value="{{ old('alias', $proveedor->alias) }}">
                            </div>
                            <div class="col-md-1 mb-3">
                                <label for="dias" class="form-label">Días Pago <b style="color: red;">(*)</b></label>
                                <input type="number" class="form-control" id="dias" name="dias" required
                                    placeholder="Ingrese días del proveedor" value="{{ old('dias', $proveedor->dias) }}">
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <a href="{{ url('/admin/proveedores/index') }}" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-info">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')
@stop

@section('js')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const provinciaSelect = document.getElementById('provincia');
            const localidadSelect = document.getElementById('localidad');
            const codPostalSelect = document.getElementById('cod_postal_id');

            const oldProvincia = @json(old('provincia', optional($proveedor->localidad)->id_prov));
            const oldLocalidad = @json(old('localidad', optional($proveedor->localidad)->id_local));
            const oldCodPostal = @json(old('cod_postal_id', $proveedor->cod_postal_id));

            const setDefaultOption = (select, text) => {
                select.innerHTML = `<option value="">${text}</option>`;
            };

            const cargarLocalidades = async (idProv, localidadSeleccionada = '') => {
                setDefaultOption(localidadSelect, 'Seleccione localidad');
                setDefaultOption(codPostalSelect, 'Seleccione codigo postal');

                if (!idProv) {
                    return;
                }

                try {
                    const endpoint = "{{ route('localidades.provincia', ['idProv' => '__ID__']) }}".replace('__ID__', encodeURIComponent(idProv));
                    const response = await fetch(endpoint, {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    const localidades = await response.json();

                    localidades.forEach((item) => {
                        const option = document.createElement('option');
                        option.value = item.id_local;
                        option.textContent = item.localidad;

                        if (localidadSeleccionada && String(localidadSeleccionada) === String(item.id_local)) {
                            option.selected = true;
                        }

                        localidadSelect.appendChild(option);
                    });

                    if (localidadSelect.value) {
                        await cargarCodigosPostales(localidadSelect.value, oldCodPostal);
                    }
                } catch (error) {
                    console.error('Error al cargar localidades:', error);
                }
            };

            const cargarCodigosPostales = async (idLocal, codPostalSeleccionado = '') => {
                setDefaultOption(codPostalSelect, 'Seleccione codigo postal');

                if (!idLocal) {
                    return;
                }

                try {
                    const endpoint = "{{ route('localidades.codigos_postales', ['idLocal' => '__ID__']) }}".replace('__ID__', encodeURIComponent(idLocal));
                    const response = await fetch(endpoint, {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    const codigos = await response.json();

                    codigos.forEach((item) => {
                        const option = document.createElement('option');
                        option.value = item.id;
                        option.textContent = item.cod_postal;

                        if (codPostalSeleccionado && String(codPostalSeleccionado) === String(item.id)) {
                            option.selected = true;
                        }

                        codPostalSelect.appendChild(option);
                    });
                } catch (error) {
                    console.error('Error al cargar codigos postales:', error);
                }
            };

            provinciaSelect.addEventListener('change', function() {
                cargarLocalidades(this.value);
            });

            localidadSelect.addEventListener('change', function() {
                cargarCodigosPostales(this.value);
            });

            if (oldProvincia) {
                provinciaSelect.value = String(oldProvincia);
                cargarLocalidades(String(oldProvincia), oldLocalidad);
            } else {
                setDefaultOption(localidadSelect, 'Seleccione localidad');
                setDefaultOption(codPostalSelect, 'Seleccione codigo postal');
            }
        });
    </script>
@stop
