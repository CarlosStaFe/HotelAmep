

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Usuarios</li>
            <li class="breadcrumb-item active" aria-current="page">Detalle del Usuario</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-success">
                <div class="card-header">
                    <h3 class="card-title"><b>Detalle del usuario</b></h3>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Nombre:</strong> <?php echo e($usuario->name); ?></p>
                            <p><strong>Email:</strong> <?php echo e($usuario->email); ?></p>
                            <p><strong>Teléfono:</strong> <?php echo e($usuario->telefono); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Rol:</strong> <?php echo e($usuario->roles->pluck('name')->join(', ') ?: 'Sin rol'); ?></p>
                            <p><strong>Estado:</strong>
                                <?php if($usuario->activo): ?>
                                    <span class="badge badge-success">Activo</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Inactivo</span>
                                <?php endif; ?>
                            </p>
                            <p><strong>Creado:</strong> <?php echo e($usuario->created_at?->format('d/m/Y H:i') ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(url('/admin/usuarios/index')); ?>" class="btn btn-secondary">Volver</a>
                        <a href="<?php echo e(route('usuarios.edit', $usuario)); ?>" class="btn btn-success">Editar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\usuarios\show.blade.php ENDPATH**/ ?>