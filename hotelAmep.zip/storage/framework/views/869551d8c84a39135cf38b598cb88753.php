

<?php $__env->startSection('title', 'Sistema de Gestión Hotelera'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Sistema de Gestión Hotelera.</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        console.log("Hi, I'm using the Laravel-AdminLTE package!");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\index.blade.php ENDPATH**/ ?>