

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Artículos</li>
            <li class="breadcrumb-item active" aria-current="page">Editar Artículo</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-info">
                <div class="card-header">
                    <h2 class="card-title"><b>Completar el formulario</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <form action="<?php echo e(url('/admin/articulos/' . $articulo->id)); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="ctrocosto_id" class="form-label">Rubro <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="rubro_id" name="rubro_id" required>
                                    <option value="">Seleccione Rubro</option>
                                    <?php $__currentLoopData = $rubros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rubro->id); ?>" <?php echo e(old('rubro_id', $articulo->rubro_id) == $rubro->id ? 'selected' : ''); ?>>
                                            <?php echo e($rubro->nombre); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['rubro_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nombre" class="form-label">Nombre <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                    placeholder="Ingrese nombre del artículo" value="<?php echo e(old('nombre', $articulo->nombre)); ?>" required>
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="stock" class="form-label">Stock</label>
                                <input type="number" class="form-control" id="stock" name="stock" value="<?php echo e($articulo->stock); ?>" readonly>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="precio" class="form-label">Precio</label>
                                <input type="number" step="0.01" class="form-control" id="precio" name="precio" value="<?php echo e($articulo->precio); ?>" readonly>
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="comanda" class="form-label">Comanda <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="comanda" name="comanda" required>
                                    <option value="1" <?php echo e(old('comanda', $articulo->comanda) == '1' ? 'selected' : ''); ?>>Sí</option>
                                    <option value="0" <?php echo e(old('comanda', $articulo->comanda) == '0' ? 'selected' : ''); ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="vencimiento" class="form-label">Vencimiento <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="vencimiento" name="vencimiento" required>
                                    <option value="1" <?php echo e(old('vencimiento', $articulo->vencimiento) == '1' ? 'selected' : ''); ?>>Sí</option>
                                    <option value="0" <?php echo e(old('vencimiento', $articulo->vencimiento) == '0' ? 'selected' : ''); ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="activo" class="form-label">Estado <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="activo" name="activo" required>
                                    <option value="1" <?php echo e(old('activo', $articulo->activo) == '1' ? 'selected' : ''); ?>>Activo</option>
                                    <option value="0" <?php echo e(old('activo', $articulo->activo) == '0' ? 'selected' : ''); ?>>Inactivo</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 mb-12">
                                <label for="observacion" class="form-label">Observación</label>
                                <textarea class="form-control" id="observacion" name="observacion" rows="2"
                                    placeholder="Ingrese observación del artículo"><?php echo e(old('observacion', $articulo->observacion)); ?></textarea>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <a href="<?php echo e(url('/admin/articulos/index')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-info">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\articulos\edit.blade.php ENDPATH**/ ?>