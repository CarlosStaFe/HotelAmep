

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Proveedores</li>
            <li class="breadcrumb-item active" aria-current="page">Ver Proveedor</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h2 class="card-title"><b>Detalle del proveedor</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="nombre" value="<?php echo e($proveedor->nombre); ?>" readonly>
                        </div>
                        <div class="col-md-4 mb-4">
                            <label for="razon_social" class="form-label">Razón Social</label>
                            <input type="text" class="form-control" id="razon_social" value="<?php echo e($proveedor->razonSocial); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="cuit" class="form-label">C.U.I.T.</label>
                            <input type="text" class="form-control" id="cuit" value="<?php echo e($proveedor->cuit); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="tipo_iva" class="form-label">Tipo I.V.A.</label>
                            <input type="text" class="form-control" id="tipo_iva" value="<?php echo e($proveedor->tipo_iva); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <label for="domicilio" class="form-label">Domicilio</label>
                            <input type="text" class="form-control" id="domicilio" value="<?php echo e($proveedor->domicilio); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="provincia" class="form-label">Provincia</label>
                            <input type="text" class="form-control" id="provincia" value="<?php echo e($proveedor->localidad->provincia ?? 'N/A'); ?>" readonly>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <label for="localidad" class="form-label">Localidad</label>
                            <input type="text" class="form-control" id="localidad" value="<?php echo e($proveedor->localidad->localidad ?? 'N/A'); ?>" readonly>
                        </div>
                        <div class="col-md-2 col-sm-2">
                            <label for="cod_postal" class="form-label">Cod.Postal</label>
                            <input type="text" class="form-control" id="cod_postal" value="<?php echo e($proveedor->localidad->cod_postal ?? 'N/A'); ?>" readonly>
                        </div>
                        <div class="col-md-4 mb-4">
                            <label for="telefono" class="form-label">Teléfono</label>
                            <input type="text" class="form-control" id="telefono" value="<?php echo e($proveedor->telefono ?? 'N/A'); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="activo" class="form-label">Estado</label>
                            <input type="text" class="form-control" id="activo" value="<?php echo e($proveedor->activo ? 'Activo' : 'Inactivo'); ?>" readonly>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <label for="observacion" class="form-label">Observación</label>
                            <textarea class="form-control" id="observacion" rows="2" readonly><?php echo e($proveedor->observacion ?? ''); ?></textarea>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <a href="<?php echo e(url('/admin/proveedores/index')); ?>" class="btn btn-success">Volver</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\proveedores\show.blade.php ENDPATH**/ ?>