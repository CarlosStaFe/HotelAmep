

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Pasajeros</li>
            <li class="breadcrumb-item active" aria-current="page">Editar Pasajero</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-info">
                <div class="card-header">
                    <h2 class="card-title"><b>Completar el formulario</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <form action="<?php echo e(url('/admin/pasajeros/' . $pasajero->id)); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-2 mb-3">
                                <label for="tipoDocumento" class="form-label">Tipo de documento <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="tipoDocumento" name="tipoDocumento" required>
                                    <option value="">Seleccione tipo de documento</option>
                                    <option value="DNI" <?php echo e(old('tipoDocumento', $pasajero->tipoDocumento) === 'DNI' ? 'selected' : ''); ?>>DNI</option>
                                    <option value="CI" <?php echo e(old('tipoDocumento', $pasajero->tipoDocumento) === 'CI' ? 'selected' : ''); ?>>CI</option>
                                    <option value="PAS" <?php echo e(old('tipoDocumento', $pasajero->tipoDocumento) === 'PAS' ? 'selected' : ''); ?>>PAS</option>
                                    <option value="LE" <?php echo e(old('tipoDocumento', $pasajero->tipoDocumento) === 'LE' ? 'selected' : ''); ?>>LE</option>
                                </select>
                                <?php $__errorArgs = ['tipoDocumento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="documento" class="form-label">Documento <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="documento" name="documento"
                                    placeholder="Ingrese documento del pasajero" value="<?php echo e(old('documento', $pasajero->documento)); ?>" required>
                                <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-5 mb-3">
                                <label for="apelyNombre" class="form-label">Apellido y Nombres <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="apelyNombre" name="apelyNombre"
                                    placeholder="Ingrese apellido y nombre del pasajero" value="<?php echo e(old('apelyNombre', $pasajero->apelyNombre)); ?>" required>
                                <?php $__errorArgs = ['apelyNombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="telefono" class="form-label">Teléfono <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="telefono" name="telefono"
                                    placeholder="Ingrese teléfono del pasajero" value="<?php echo e(old('telefono', $pasajero->telefono)); ?>" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label for="direccion" class="form-label">Domicilio <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="direccion" name="direccion"
                                    placeholder="Ingrese domicilio del proveedor" value="<?php echo e(old('direccion', $pasajero->direccion)); ?>" required>
                                <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="provincia">Provincia <b style="color: red;">(*)</b></label>
                                    <select type="text" class="form-control" value="<?php echo e(strtoupper($pasajero->localidad->provincia ?? 'N/A')); ?>" id="provincia" name="provincia"       placeholder="Provincia">
                                        <option value="<?php echo e($pasajero->localidad->id_prov); ?>"><?php echo e(strtoupper($pasajero->localidad->provincia ?? 'N/A')); ?></option>
                                        <option value="6">BUENOS AIRES</option>
                                        <option value="2">CABA</option>
                                        <option value="10">CATAMARCA</option>
                                        <option value="22">CHACO</option>
                                        <option value="26">CHUBUT</option>
                                        <option value="18">CORRIENTES</option>
                                        <option value="14">CORDOBA</option>
                                        <option value="30">ENTRE RIOS</option>
                                        <option value="34">FORMOSA</option>
                                        <option value="38">JUJUY</option>
                                        <option value="42">LA PAMPA</option>
                                        <option value="46">LA RIOJA</option>
                                        <option value="50">MENDOZA</option>
                                        <option value="54">MISIONES</option>
                                        <option value="58">NEUQUEN</option>
                                        <option value="62">RIO NEGRO</option>
                                        <option value="70">SAN JUAN</option>
                                        <option value="74">SAN LUIS</option>
                                        <option value="66">SALTA</option>
                                        <option value="78">SANTA CRUZ</option>
                                        <option value="82">SANTA FE</option>
                                        <option value="86">SANTIAGO DEL ESTERO</option>
                                        <option value="94">TIERRA DEL FUEGO</option>
                                        <option value="90">TUCUMAN</option>
                                    </select>
                                    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color: red"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="form-group">
                                    <label for="localidad">Localidad <b style="color: red;">(*)</b></label>
                                    <select type="text" class="form-control" value="<?php echo e(strtoupper($pasajero->localidad->localidad ?? 'N/A')); ?>" id="localidad" name="localidad"        placeholder="Localidad">
                                        <option value="<?php echo e($pasajero->localidad->id_local); ?>"><?php echo e(strtoupper($pasajero->localidad->localidad ?? 'N/A')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['localidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color: red"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-2">
                                <div class="form-group">
                                    <label for="cod_postal">Cod.Postal <b style="color: red;">(*)</b></label>
                                    <select type="text" class="form-control" value="<?php echo e($pasajero->localidad->cod_postal ?? 'N/A'); ?>" id="cod_postal" name="cod_postal" placeholder="Código">
                                        <option value="<?php echo e($pasajero->localidad->id); ?>"><?php echo e(strtoupper($pasajero->localidad->cod_postal ?? 'N/A')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['cod_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color: red"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <label for="email" class="form-label">Email <b style="color: red;">(*)</b></label>
                                <input type="email" class="form-control" id="email" name="email"
                                    placeholder="Ingrese email del pasajero" value="<?php echo e(old('email', $pasajero->email)); ?>" required>
                            </div>
                            <div class="col-md-2 col-sm-2">
                                <label for="usaComanda" class="form-label">Usa Comanda <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="usaComanda" name="usaComanda" required>
                                    <option value="">Seleccione una opción</option>
                                    <option value="1" <?php echo e((old('usaComanda', $pasajero->usaComanda) ?? 0) == 1 ? 'selected' : ''); ?>>Sí</option>
                                    <option value="0" <?php echo e((old('usaComanda', $pasajero->usaComanda) ?? 0) == 0 ? 'selected' : ''); ?>>No</option>
                                </select>
                                <?php $__errorArgs = ['usaComanda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <a href="<?php echo e(url('/admin/pasajeros/index')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-info">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const provinciaSelect = document.getElementById('provincia');
            const localidadSelect = document.getElementById('localidad');
            const codPostalSelect = document.getElementById('cod_postal_id');

            const oldProvincia = <?php echo json_encode(old('provincia', optional($proveedor->localidad)->id_prov), 512) ?>;
            const oldLocalidad = <?php echo json_encode(old('localidad', optional($proveedor->localidad)->id_local), 512) ?>;
            const oldCodPostal = <?php echo json_encode(old('cod_postal_id', $proveedor->cod_postal_id), 512) ?>;

            const setDefaultOption = (select, text) => {
                select.innerHTML = `<option value="">${text}</option>`;
            };

            const cargarLocalidades = async (idProv, localidadSeleccionada = '') => {
                setDefaultOption(localidadSelect, 'Seleccione localidad');
                setDefaultOption(codPostalSelect, 'Seleccione codigo postal');

                if (!idProv) {
                    return;
                }

                try {
                    const endpoint = "<?php echo e(route('localidades.provincia', ['idProv' => '__ID__'])); ?>".replace('__ID__', encodeURIComponent(idProv));
                    const response = await fetch(endpoint, {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    const localidades = await response.json();

                    localidades.forEach((item) => {
                        const option = document.createElement('option');
                        option.value = item.id_local;
                        option.textContent = item.localidad;

                        if (localidadSeleccionada && String(localidadSeleccionada) === String(item.id_local)) {
                            option.selected = true;
                        }

                        localidadSelect.appendChild(option);
                    });

                    if (localidadSelect.value) {
                        await cargarCodigosPostales(localidadSelect.value, oldCodPostal);
                    }
                } catch (error) {
                    console.error('Error al cargar localidades:', error);
                }
            };

            const cargarCodigosPostales = async (idLocal, codPostalSeleccionado = '') => {
                setDefaultOption(codPostalSelect, 'Seleccione codigo postal');

                if (!idLocal) {
                    return;
                }

                try {
                    const endpoint = "<?php echo e(route('localidades.codigos_postales', ['idLocal' => '__ID__'])); ?>".replace('__ID__', encodeURIComponent(idLocal));
                    const response = await fetch(endpoint, {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    const codigos = await response.json();

                    codigos.forEach((item) => {
                        const option = document.createElement('option');
                        option.value = item.id;
                        option.textContent = item.cod_postal;

                        if (codPostalSeleccionado && String(codPostalSeleccionado) === String(item.id)) {
                            option.selected = true;
                        }

                        codPostalSelect.appendChild(option);
                    });
                } catch (error) {
                    console.error('Error al cargar codigos postales:', error);
                }
            };

            provinciaSelect.addEventListener('change', function() {
                cargarLocalidades(this.value);
            });

            localidadSelect.addEventListener('change', function() {
                cargarCodigosPostales(this.value);
            });

            if (oldProvincia) {
                provinciaSelect.value = String(oldProvincia);
                cargarLocalidades(String(oldProvincia), oldLocalidad);
            } else {
                setDefaultOption(localidadSelect, 'Seleccione localidad');
                setDefaultOption(codPostalSelect, 'Seleccione codigo postal');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\pasajeros\edit.blade.php ENDPATH**/ ?>