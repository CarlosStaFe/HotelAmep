

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Calendario</li>
            <li class="breadcrumb-item active" aria-current="page">Disponibilidad de Habitaciones</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-bottom: 15px;">
        <div class="col-md-12">
            <form action="<?php echo e(route('calendarios.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Generar Disponibilidad</h3>
                    </div>
                    <br>
                    <div class="row mb-3">
                        <div class="ml-1 col-md-2">
                            <label for="habitacion_id">HABITACIÓN <b style="color: red;">(*)</b></label>
                            <select class="form-control" id="habitacion_id" name="habitacion_id" required>
                                <option value="">Seleccione una habitación</option>
                                <?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($habitacion->id); ?>" <?php if(old('habitacion_id') == $habitacion->id): echo 'selected'; endif; ?>>
                                        <?php echo e($habitacion->numero); ?> - <?php echo e($habitacion->tipo); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['habitacion_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-2">
                            <label for="fecha_inicio">FECHA INICIO <b style="color: red;">(*)</b></label>
                            <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-control"
                                   value="<?php echo e(old('fecha_inicio', date('Y-m-d'))); ?>" min="<?php echo e(date('Y-m-d')); ?>" required>
                            <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-2">
                            <label for="fecha_fin">FECHA FIN <b style="color: red;">(*)</b></label>
                            <input type="date" name="fecha_fin" id="fecha_fin" class="form-control"
                                   value="<?php echo e(old('fecha_fin', date('Y-m-d', strtotime('+30 days')))); ?>" min="<?php echo e(date('Y-m-d')); ?>" required>
                            <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-2">
                            <label for="estado">ESTADO <b style="color: red;">(*)</b></label>
                            <select class="form-control" id="estado" name="estado" required>
                                <?php $__currentLoopData = ['Disponible', 'No Disponible', 'Reservada', 'Ocupada']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($estado); ?>" <?php if(old('estado', 'Disponible') === $estado): echo 'selected'; endif; ?>>
                                        <?php echo e($estado); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6 ml-1">
                            <div class="form-group">
                                <a href="<?php echo e(url('/admin/calendarios/disponibilidad')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Generar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\calendarios\disponibilidad.blade.php ENDPATH**/ ?>