

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Artículos</li>
            <li class="breadcrumb-item active" aria-current="page">Crear Artículo</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-primary">
                <div class="card-header">
                    <h2 class="card-title"><b>Completar el formulario</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <form action="<?php echo e(url('/admin/articulos/create')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="rubro_id" class="form-label">Rubro <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="rubro_id" name="rubro_id" required>
                                    <option value="">Seleccione Rubro</option>
                                    <?php $__currentLoopData = $rubros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rubro->id); ?>"
                                            <?php echo e(old('rubro_id') == $rubro->id ? 'selected' : ''); ?>>
                                            <?php echo e($rubro->nombre); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nombre" class="form-label">Nombre <b style="color: red;">(*)</b></label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                    placeholder="Ingrese nombre del artículo" value="<?php echo e(old('nombre')); ?>" required>
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 mb-2">
                                <label for="comanda" class="form-label">Comanda <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="comanda" name="comanda" required>
                                    <option value="0" <?php echo e(old('comanda', '0') == '0' ? 'selected' : ''); ?>>No</option>
                                    <option value="1" <?php echo e(old('comanda') === '1' ? 'selected' : ''); ?>>Si</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="activo" class="form-label">Estado <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="activo" name="activo" required>
                                    <option value="1" <?php echo e(old('activo', '1') == '1' ? 'selected' : ''); ?>>Activo</option>
                                    <option value="0" <?php echo e(old('activo') === '0' ? 'selected' : ''); ?>>Inactivo</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="vencimiento" class="form-label">Vencimiento <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="vencimiento" name="vencimiento" required>
                                    <option value="0" <?php echo e(old('vencimiento', '0') == '0' ? 'selected' : ''); ?>>No</option>
                                    <option value="1" <?php echo e(old('vencimiento') === '1' ? 'selected' : ''); ?>>Si</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-6">
                                <label for="observacion" class="form-label">Observación</label>
                                <textarea class="form-control" id="observacion" name="observacion" rows="2"
                                    placeholder="Ingrese observación del artículo"><?php echo e(old('observacion')); ?></textarea>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <a href="<?php echo e(url('/admin/articulos/index')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- /.card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\articulos\create.blade.php ENDPATH**/ ?>