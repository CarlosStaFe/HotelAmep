

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Artículos</li>
            <li class="breadcrumb-item active" aria-current="page">Eliminar Artículo</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-danger">
                <div class="card-header">
                    <h2 class="card-title"><b>Eliminar Artículo</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <div class="mb-6">
                        <label for="ctrocosto_id" class="form-label">Rubro</label>
                        <input type="text" class="form-control" id="rubro_id" name="rubro_id" value="<?php echo e($articulo->rubro->nombre); ?>" readonly>
                    </div>
                    <div class="mb-6">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($articulo->nombre); ?>" readonly>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label for="stock" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="stock" name="stock" value="<?php echo e($articulo->stock); ?>" readonly>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="precio" class="form-label">Precio</label>
                            <input type="number" step="0.01" class="form-control" id="precio" name="precio" value="<?php echo e($articulo->precio); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="comanda" class="form-label">Comanda</label>
                            <input type="text" class="form-control" id="comanda" name="comanda"
                                value="<?php echo e($articulo->comanda ? 'Sí' : 'No'); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="vencimiento" class="form-label">Vencimiento</label>
                            <input type="text" class="form-control" id="vencimiento" name="vencimiento"
                                value="<?php echo e($articulo->vencimiento ? 'Sí' : 'No'); ?>" readonly>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label for="activo" class="form-label">Estado</label>
                            <input type="text" class="form-control" id="activo" name="activo"
                                value="<?php echo e($articulo->activo ? 'Activo' : 'Inactivo'); ?>" readonly>
                        </div>
                    </div>
                    <div>
                        <div class="mb-5">
                            <label for="observacion" class="form-label">Observación</label>
                            <textarea class="form-control" id="observacion" name="observacion" rows="2" readonly><?php echo e($articulo->observacion); ?></textarea>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <form action="<?php echo e(url('/admin/articulos/' . $articulo->id)); ?>" method="POST"
                                    style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a href="<?php echo e(url('/admin/articulos/index')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\articulos\delete.blade.php ENDPATH**/ ?>