

<?php $__env->startSection('content_header'); ?>
    <nav aria-label="breadcrumb" style="font-size: 14pt">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Artículos</li>
            <li class="breadcrumb-item active" aria-current="page">Ajuste de Artículo</li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-info">
                <div class="card-header">
                    <h2 class="card-title"><b>Completar el formulario</b></h2>
                </div>
                <div class="card-body" style="box-sizing: border-box; display: block;">
                    <form action="<?php echo e(url('/admin/articulos/' . $articulo->id . '/grabar-ajuste')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="ctrocosto_id" class="form-label">Rubro</label>
                                <input type="text" class="form-control" id="rubro_id" name="rubro_id" value="<?php echo e($articulo->rubro->nombre); ?>" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nombre" class="form-label">Nombre</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($articulo->nombre); ?>" readonly>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 mb-2">
                                <label for="tipo" class="form-label">Tipo de Movimiento <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="tipo" name="tipo" required>
                                    <option value="">Seleccione tipo</option>
                                    <option value="Entrada">Entrada</option>
                                    <option value="Salida">Salida</option>
                                </select>
                                <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="cantidad" class="form-label">Cantidad <b style="color: red;">(*)</b></label>
                                <input class="form-control" type="number" id="cantidad" name="cantidad" min="0.001" step="0.001" value="<?php echo e(old('cantidad')); ?>" required>
                                <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-2 mb-2">
                                <label for="motivo" class="form-label">Motivo <b style="color: red;">(*)</b></label>
                                <select class="form-control" id="motivo" name="motivo" required>
                                    <option value="">Seleccione motivo</option>
                                    <option value="Ajuste" <?php echo e(old('motivo', 'Ajuste') === 'Ajuste' ? 'selected' : ''); ?>>Ajuste</option>
                                    <option value="Rotura" <?php echo e(old('motivo') === 'Rotura' ? 'selected' : ''); ?>>Rotura</option>
                                    <option value="Perdida" <?php echo e(old('motivo') === 'Perdida' ? 'selected' : ''); ?>>Perdida</option>
                                    <option value="Vencido" <?php echo e(old('motivo') === 'Vencido' ? 'selected' : ''); ?>>Vencido</option>
                                    <option value="Desgaste" <?php echo e(old('motivo') === 'Desgaste' ? 'selected' : ''); ?>>Desgaste</option>
                                    <option value="Baja" <?php echo e(old('motivo') === 'Baja' ? 'selected' : ''); ?>>Baja</option>
                                </select>
                                <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div>
                            <div class="mb-5">
                                <label for="observacion" class="form-label">Observación del ajuste <b style="color: red;">(*)</b></label>
                                <textarea class="form-control" id="observacion" name="observacion" required><?php echo e(old('observacion')); ?></textarea>
                                <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <hr>
                        <div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <a href="<?php echo e(url('/admin/articulos/index')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-info">Modificar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\HotelAmep\resources\views\admin\articulos\ajuste.blade.php ENDPATH**/ ?>