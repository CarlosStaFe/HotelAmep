<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Tus datos de acceso</title>
</head>
<body>
    <p>Hola <?php echo e($usuario->name); ?>,</p>

    <p>Estos son tus datos para ingresar:</p>
    <p><strong>Correo:</strong> <?php echo e($usuario->email); ?></p>
    <p><strong>Contraseña:</strong> <?php echo e($password); ?></p>

    <p><a href="<?php echo e(config('app.url')); ?>">Ingresar al sistema</a></p>
    <p>Por seguridad, no compartas esta contraseña.</p>
</body>
</html>
<?php /**PATH D:\Laravel\HotelAmep\resources\views\emails\usuario-creado.blade.php ENDPATH**/ ?>