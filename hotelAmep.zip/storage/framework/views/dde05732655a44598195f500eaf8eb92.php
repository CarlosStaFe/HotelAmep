<li class="nav-item">
    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
    </a>
</li>
<?php /**PATH D:\Laravel\HotelAmep\vendor\jeroennoten\laravel-adminlte\resources\views\partials\navbar\menu-item-fullscreen-widget.blade.php ENDPATH**/ ?>